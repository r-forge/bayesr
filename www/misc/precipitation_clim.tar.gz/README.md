


WHAT DOES THESE SCRIPTS CONTAIN
===============================
These scripts are offering the supplementary material for the article
"Spatio-Temporal Precipitation Climatology over Complex Terrain Using a
Censored Additive Regression Model" which allows to reproduce the models
used in the article.


FILE DESCRIPTION
================

LICENSE
-------
Contains the license for the required data sets. Three different sources will 
be used. The first source contains the observations, provided by the 
BMLFUW (see _LICENSE_ file for more details). This file will be provided 
with this _README_ file. Furthermore, the SRTM digital elevation model (CGIAR)
and the boundaries of the state of Tyrol (GADM) are included in the data
set.

clim.R
------
Main R-script to reproduce the climate estimates.  The R-package _bamlss_ will
be installed automatically, if not yet installed on the system.

Dependencies:
- Scripts: functions.R
- R-packages: bamlss, sp, raster, rgdal, zoo, colorspace

Configs:
-  variable max_stations: either NULL, or an integer value between 1,...,117.
   Defines for which stations the stationwise estimates should be computed.
   If NULL, the estimates will be computed for all stations. If set to an
   integer value, only the first 1:N stations will be concidered.
-  variable spatial_training: either a two element vector (begin year, end
   year), or NULL. If set to NULL, all observations will be used to create the
   spatial model. If a vector is given (begin year, end year) only these years
   will be used. The default is "c(2000,2004)". In this case, only 5 years of
   observations (2000,...,2004) will be used for modelling.  Computational
   time/memory requirements (Intel Xeon X5650 2.7 GHz CPU): for 5 years training
   data set approximately 6.5 hours, 3 GB memory.  When using all available
   training data (1971-2012; spatial_training set to "NULL": roughly 25 hours, 6.5
   GB memory.

Short description what the script does:
0) loading required packages. If R-package _bamlss_ is not available, try
   to install automatically from R-Forge. Furthermore, loading training data
   set _data.rda_, the digital elevation model (_dem.rds_; raster object),
   and the boundaries of the state of Tyrol (GADM; sp).
1) estimating monthly mean climatologies (_monmod_). Estimates will be
   stored in a subfolder _monmod_ which will be created automatically.
   If the output file is already existing: skip
2) compute stationwise GAMLSS models (_station_) with a constant power
   parameter of p=1.6. As for the monthly mean
   models: stores estimates into a subfolder _stationwise GAMLSS_. If 
   output file exists: skip, else create the estimates using the _bamlss_ package.
3) compute stationwise GAMLSS models (_powopt_) simultanously estimating
   a constant power parameter. As for the other two models in (1), (2) :
   stores estimates into a subfolder _stationwise power_. If 
   output file exists: skip, else create the estimates using the _bamlss_ package.
4) estimating the full spatio-temporal climatology. This can take a while.
   The estimated models will be stored in a subfolder called _spatial GAMLSS_.
   If the output file exists, skip.
5) create predictions of all different model types from (1)-(4) and plotting
   the data to compare the outcome of the different estimates.
6) demo of a spatial prediction.

functions.R
-----------
Functions required by _clim.R_. Contains a function to compute the expectation
for power-transformed zero-left-censored normal distributions, and several
helper functions required by _clim.R_.

data.rda
--------
Observation data. Contains a data.frame object with the observations.
For licnence details please read the _LICENSE_ file.


Update
------
Updated in December 2020, the archive now includes the digital elevation
data set and the GADM boundaries needed.


