# -------------------------------------------------------------------
# - NAME:        clim.R
# - AUTHOR:      Reto Stauffer
# - DATE:        2016-03-15
# -------------------------------------------------------------------
# - DESCRIPTION: Supplementary code for the article "Spatio-Temporal
#                Precipitation Climatology over Complex Terrain
#                Using a Censored Additive Regression Model".
#
#                There is a README file beside this R-source code
#                which offers some more details.
# -------------------------------------------------------------------
# - LICENSE:     Copyright (c) 2016, Reto Stauffer, Department of
#                Statistics, University of Innsbruck, Austria.
#                Contact: reto.stauffer@uibk.ac.at.
#                This script is free software published under the terms
#                of the GPLv3. For details please read the "LICENSE"
#                file which comes alongside this source file.
# -------------------------------------------------------------------
# - EDITORIAL:   2016-03-15, RS: Created file on thinkreto.
# -------------------------------------------------------------------
# - L@ST MODIFIED: 2016-04-03 11:24 on thinkreto
# -------------------------------------------------------------------


# -------------------------------------------------------------------
# Loading required packages.
# -------------------------------------------------------------------
   library("sp")
   library("raster")
   library("rgdal")
   library("zoo")
   library("colorspace")
   source('functions.R') # required functions

   # Requires BAMLSS package. Results for the article were created using
   # the R package "bamlss" on svn revision 1711 (2016-03-15).
   # Package source can be downloaded from R-forge:
   # URL: https://r-forge.r-project.org/scm/?group_id=865
   check <- try( library("bamlss") )
   if ( any("try-error" %in% class(check)) ) {
      cat(" * Trying to install the bamlss package now\n")
      install.packages("bamlss", repos="http://R-Forge.R-project.org")
   }

# -------------------------------------------------------------------
# There are totally 117 stations in the data set.
# If the setting "max_stations = NA" the "monthly mean" climatology,
# the "stationwise GAMLSS", and the "stationwise GAMLSS with optimized
# power parameter (powopt)" models will be computed for all 117
# stations in the data set. If set to a positive integer [1,117] only
# the first 1:N stations will be used (for testing/demo).
# -------------------------------------------------------------------

   # Only compute stationwise models for the first N stations
   max_stations <- 1
   # Compute stationwise models for all stations in the data set
   #max_stations <- NA 

# -------------------------------------------------------------------
# Observations are available between 1971--2012 (42 years) including
# roughly 1.6 million unique observations. Estimating the full
# spatio-temporal model including all available data points takes
# quite a while. If "spatial_training=NULL" the spatio-temporal model
# will be fitted on the full data set. If "spatial_training" is a
# a vector "c(start_year,end_year)" only a subset will be included.
# Reduces time needed to fit the model, but strongly influences the
# results as only a subset of data is concidered.
# Resources needed for model estimation (Intel Xenon 2.7 GHz)
# - full model:   6.5GB memory,  25 hours, output 540 MB
# - 2000-2004:    3.0GB memory, 6.5 hours, output 440 MB
# -------------------------------------------------------------------

   # Only using 5 years for training (2000--2004) 
   spatial_training <- c(2000,2004)
   # Take all available data (full training data set)
   #spatial_training <- NULL
   

# -------------------------------------------------------------------
# Loading the data
# -------------------------------------------------------------------

   # Loading observations (EHYD)
   cat(" * Loading observational data set\n")
   load("data.rda")
   data$yday <- as.POSIXlt(data$date)$yday         # day of the year
   data$mon  <- as.POSIXlt(data$date)$mon  + 1     # month 1,...,12
   data$year <- as.POSIXlt(data$date)$year + 1900  # year (YYYY)

   # Loading SRTM digital elevation model data. Starts downloading
   # the data automatically if not already available.
   cat(" * Loading SRTM data set\n")
   if ( ! file.exists("dem.rda") ) {
      dem <- download_SRTM(fact=20); save(file="dem.rda",dem)
   } else { load("dem.rda") }

   # Loading boundaries of the state of Tyrol. If not existing,
   # download from the GADM website automatically.
   cat(" * Loading state boundaries\n")
   if ( ! file.exists("tirol.rda") ) {
      source("functions.R"); tirol <- download_GADM(); save(file="tirol.rda",tirol)
   } else { load("tirol.rda") }

   # Demo plot
   plot( dem, col=gray.colors(51), main="SRTM topography" );
   plot( tirol, lwd=2, lwd=5.0, add=TRUE, border="white" )
   plot( tirol, lwd=2, lwd=2.5, add=TRUE )

# -------------------------------------------------------------------
# (1) Create stationwise "monthly mean" estimates.
# -------------------------------------------------------------------
   
   cat(" * Create stationwise monthly mean climatologies\n") 
   # Getting unique station names from the observational data set
   stations <- unique(as.character(data$station))
   pb <- txtProgressBar(0,min(length(stations),max_stations,na.rm=TRUE),style=3)
   # Looping over 
   dir.create("monmod",showWarnings=FALSE)
   for ( s in 1:min(length(stations),max_stations,na.rm=TRUE) ) {
      # Define output file name. If the model already exists, load
      # and make the prediction. Else create estimates. 
      modelfile <- sprintf("monmod/%s.rda",nicename(stations[s]))
      if ( file.exists(modelfile) ) { next } else {
         # Picking training and test data set for this station. 
         train <- subset( data, as.character(station) == stations[s] )
         # Skipping months with missing data. For simplicity: take all
         # months including 28 or more observations.
         hash <- strftime(train$date,"%Y-%m")
         num  <- aggregate(rep(1,nrow(train)),by=list(hash),FUN=sum)
         drop <- as.character(num[num[,2]<28,][,1])
         if ( length(drop) > 0 )
            train <- train[-which(hash %in% drop),]
         # Generate climatological values. Mean and median of the observed
         # daily precipitation sums, plus the mean observed frequency of
         # precipitation as 'probability'.
         train.mean   <- aggregate( train$obs, by=list(train$mon), FUN=mean )
         train.median <- aggregate( train$obs, by=list(train$mon), FUN=median )
         train.prob   <- aggregate( train$obs > 0, by=list(train$mon), FUN=mean )
         q75 <- function(x) quantile(x,0.75); q90 <- function(x) quantile(x,0.9)
         train.q75    <- aggregate( train$obs, by=list(train$mon), FUN=q75 )
         train.q90    <- aggregate( train$obs, by=list(train$mon), FUN=q90 )
         monmod <- data.frame("mon"   = train.mean[,1],  "mean" = train.mean[,2],
                              "median"=train.median[,2], "q75"   = train.q75[,2],
                              "q90"   = train.q90[,2],   "prob0"= train.prob[,2])
         # Save estimate
         save(file=modelfile,monmod)
         # Updating progress bar
      }
      setTxtProgressBar(pb,s)
   }
   close(pb)


# -------------------------------------------------------------------
# (2) Create "stationwise GAMLSS" estimates.
# -------------------------------------------------------------------

   cat(" * Create stationwise GAMLSS climatologies with fixed power parameter (p=1.6)\n") 
   # Create folder to store stationwise models
   dir.create("stationwise_GAMLSS",showWarnings=FALSE)
   for ( s in 1:min(length(stations),max_stations,na.rm=TRUE) ) {
      # Define output file name. If the model already exists, load
      # and make the prediction. Else estimate bamlss model.
      modelfile <- sprintf("stationwise_GAMLSS/%s.rda",nicename(stations[s]))
      if ( file.exists(modelfile) ) { next } else {
         # Picking training and test data set for this station.
         train <- subset( data, as.character(station) == stations[s] )
         # Estimate left-censored GAMLSS (bamlss model)
         formula   <- list("mu"    = I(obs^(1/1.6)) ~ ti(yday,k=12,bs='cc'),
                           "sigma" =                ~ ti(yday,k=12,bs='cc'))
         mod <- bamlss( formula, data=train, family="cnorm", 
                        gam.side=FALSE, binning=TRUE, before=TRUE,
                        maxit=100, thin=4, burnin=1000, n.iter=4000, 
                        results=FALSE, samplestats=FALSE )
         attr(mod,'station')    <- stations[s]
         attr(mod,'station_id') <- s
         save(file=modelfile,mod)
      }
   }


# -------------------------------------------------------------------
# (3) Compute stationwise GAMLSS with optimization of the power parameter
#     (estimating one constant power parameter alpha)
# -------------------------------------------------------------------
   cat(" * Create stationwise GAMLSS climatologies, modelling power parameter simultaneously\n") 
   # Getting unique station names from the observational data set
   stations <- unique(as.character(data$station))
   # Create folder to store stationwise models
   dir.create("stationwise_power",showWarnings=FALSE)
   for ( s in 1:min(length(stations),max_stations,na.rm=TRUE) ) {
      # Define output file name. If the model already exists, load
      # and make the prediction. Else estimate bamlss model.
      modelfile <- sprintf("stationwise_power/%s.rda",nicename(stations[s]))
      if ( file.exists(modelfile) ) {
         next 
      } else {
         # Picking training and test data set for this station.
         train <- subset( data, as.character(station) == stations[s] )
         # Estimate left-censored GAMLSS (bamlss model)
         formula   <- list("mu"    = obs ~ ti(yday,k=12,bs='cc'),
                           "sigma" =     ~ ti(yday,k=12,bs='cc'),
                           "alpha" =     ~ 1)
         mod <- bamlss( formula, data=train, family="pcnorm", 
                        gam.side=FALSE, binning=TRUE, before=TRUE,
                        maxit=100, thin=4, burnin=1000, n.iter=4000, 
                        results=FALSE, samplestats=FALSE )
         attr(mod,'station')    <- stations[s]
         attr(mod,'station_id') <- s
         save(file=modelfile,mod)
      }
   }


# -------------------------------------------------------------------
# (4) Compute full left-censored spatio-temporal GAMLSS model.
#     Note: requires roughly 6GB of memory (vmem max) and about
#     50 hours to estimate the full model (depends on the hardware).
# -------------------------------------------------------------------

   cat(" * Start estimating the full spatio-temporal GAMLSS\n")

   # Checking config, subsetting training data set if wished by the user
   if ( is.null(spatial_training) ) {
      cat("   Using all available observations as training data for the spatial model\n")
      train <- data
   } else {
      cat("   Using a subset of all observations for training the spatial model:\n")
      train <- subset(data,year>=min(spatial_training) & year <= max(spatial_training))
      if ( nrow(train) == 0 ) {  
         stop("Sorry, config for 'spatial_training' wrong. No training data left!\n")
      } else {
         cat("   Using a subset of all observations as training data set for the spatial model:\n")
         cat(sprintf("   Using years: %d to %d\n",min(train$year),max(train$year))) 
      }
   }

   # Estimate left-censored GAMLSS (bamlss model)
   formula <- list(
      "mu"    = I(obs^(1/1.6)) ~ s(alt,k=5) + ti(yday, k=10, mp=TRUE, bs="cc")
                               + ti(lon, lat, bs="tp", d=2, k=20)
                               + ti(yday, lon, lat, bs=c('cc','tp'), d=c(1,2), mp=TRUE,  k=c(8,20) ),
      "sigma" =                ~ s(alt,k=5) + ti(yday, k=6, mp=TRUE, bs="cc")
                               + ti(lon, lat, bs="tp", d=2, k=20)
                               + ti(yday, lon, lat, bs=c('cc','tp'), d=c(1,2), mp=TRUE,  k=c(8,20) )
      )

   # Estimating the model
   extra        <- sprintf("_%04d_%04d", min(train$year), max(train$year))
   legend_extra <- sprintf("%04d-%04d",  min(train$year), max(train$year))
   modelfile <- sprintf("spatial_GAMLSS/spatiotemporal_climatology%s.rda",extra)
   dir.create("spatial_GAMLSS",showWarnings=FALSE)
   if ( ! file.exists(modelfile) ) {
      mod <- bamlss( formula, data=train, family="cnorm", 
                     gam.side=FALSE, binning=TRUE, before=TRUE, cores=1,
                     maxit=100, eps=0.001, thin=4, burnin=1000, n.iter=4000, 
                     results=FALSE, samplestats=FALSE )
      save(file=modelfile,mod)
   } else {
      load(modelfile)
   }


# -------------------------------------------------------------------
# (5) Well, now we have estimated all models.
#     - monmod:    monthly mean values
#     - station:   stationwise model with fixed power parameter p=1.6
#     - poweropt:  stationwise model simultaniously estimating a constant
#                  power parameter
#     - spatial:   full spatial model (on a subset of all observations,
#                  or not, depending on the config of spatial_training)
#     Now plotting the different estimates for all these models.
# -------------------------------------------------------------------

   # Small helper function
   addestimates <- function(x,...) {
      lines( x$median, lwd=2, lty=1, ... )
      lines( x$q75,    lwd=2, lty=2, ... )
      lines( x$q90,    lwd=2, lty=3, ... )
   }
   # Small helper function to add nice x-axis labels
   addaxis <- function() {
      par(xaxt="s")
      ax <- as.POSIXlt(sprintf("2010-%02d-01",2:12))$yday
      axis(side=1,at=ax,label=NA)
      ax <- as.POSIXlt(sprintf("2010-%02d-15",1:12))
      axis(side=1,at=ax$yday,label=strftime(ax,"%b"),tick=FALSE)
      par(xaxt="n")
   }
   
   # Getting unique station names from the observational data set
   stations <- unique(as.character(data$station))
   # Create folder to store stationwise models
   dir.create("stationwise_power",showWarnings=FALSE)
   for ( s in 1:min(length(stations),max_stations,na.rm=TRUE) ) {

      # Loading monmod estimates
      file <- sprintf("monmod/%s.rda",nicename(stations[s]))
      monmod <- getestimates(file,stations[s])
      # Loading stationwise GAMLSS with p=1.6
      file <- sprintf("stationwise_GAMLSS/%s.rda",nicename(stations[s]))
      station <- getestimates(file,stations[s])
      # Loading stationwise GAMLSS with optimized power parameter
      file <- sprintf("stationwise_power/%s.rda",nicename(stations[s]))
      powopt <- getestimates(file,stations[s])
      # Loading spatial model. Requires station coordinates
      coord <- subset(data[as.character(data$station)==stations[s],][1,],select=c(station,lon,lat,alt))
      file <- sprintf("spatial_GAMLSS/spatiotemporal_climatology%s.rda",extra)
      spatial <- getestimates(file,coord)

      # --------------------------------------
      # Initialize plot
      # --------------------------------------
      layout(matrix(c(1,2),nrow=2),heights=c(.8,.2))
      par(xaxs="i",yaxs="i",xaxt="n",oma=c(2,0,2,0),mar=c(.5,4,0,1))

      # --------------------------------------
      # Plotting amount of precipitation
      # --------------------------------------
      plot( 0, type="n", xlim=range(index(station)), ylim=c(0,max(station$q90)*1.20),
         ylab="precipitation [mm/day]", xlab=NA,main=NA)
      mtext(side=3,line=.5,sprintf("Estimated precipitation climatology, Station %s",stations[s]))

      # Adding observed quantiles to the plot
      tmp <-obsquantiles( subset(data,as.character(data$station) == stations[s]) )

      cols <- c("#D67288","#66A038","#0C9CCD")
      addestimates(monmod,   col=1)
      addestimates(station,  col=cols[1])
      addestimates(powopt,   col=cols[2])
      addestimates(spatial,  col=cols[3])

      leg <- c("observed","monmon",sprintf("station [pow=%.2f]",attr(station,"power")),
               sprintf("powopt [pow=%.2f]",attr(powopt,"power")),
               sprintf("spatial [pow=%.2f;%s]",attr(spatial,"power"),legend_extra))
      legend("topleft",bty="n",legend=leg,fill=c(rgb(0,0,0,0.4),1,cols))

      # --------------------------------------
      # Plotting probability of precipitation
      # --------------------------------------
      plot(0,type="n", xlim=range(index(station)), ylim=c(0,1),
         ylab="pop [%]", xlab=NA,main=NA)
      lines(monmod$prob0,  col=1 )
      lines(station$prob0, col=cols[1] )
      lines(powopt$prob0,  col=cols[2] )
      lines(spatial$prob0, col=cols[3] )
      
      addaxis()

   }


# -------------------------------------------------------------------
# (6) Create spatial prediction for two days.
#     Loading the spatio-temporal estimates and makes predictions
#     for January 1, and June 1.
# -------------------------------------------------------------------

   file <- sprintf("spatial_GAMLSS/spatiotemporal_climatology%s.rda",extra)
   load(file) # Loading the spatio-temporal model on variable 'mod' 

   # Cropping digital elevation model to the extent of the boundaries
   # of the state of Tyrol
   dem <- crop(dem,extent(tirol))
   # Identify pixels outside the state of Tyrol
   sp   <- SpatialPoints(coordinates(dem),proj4string=crs(tirol))
   take <- which(!is.na(over(sp,tirol)))
   values(dem)[!take] <- NA
   # Create newdata data.frame for the prediction
   newdata <- as.data.frame(coordinates(dem)); names(newdata) <- c('lon','lat')
   newdata$alt <- values(dem)
   newdata <- newdata[take,]
   # Create RasterStack object to store the predictions
   res <- dem; values(res) <- NA
   res <- stack(res,res,res,res,res,res)
   names(res) <- c('mu','logsd','prob0','exp','q75','q90')
   
   for ( dv in dev.list() ) dev.off()
   dates <- c("2015-01-01","2015-06-01")
   for ( date in dates ) {
      # Convert date, picking day of the year
      date <- as.POSIXlt(date)
      newdata$yday <- date$yday

      # --------------------------------------
      # Spatial predictions
      # --------------------------------------
      # Predict location, and scale from the spatio-temporal model
      tmp <- predict(mod,newdata=newdata)
      # Store latent location and scale of the estimates
      values(res$mu)[take]    <- tmp$mu
      values(res$logsd)[take] <- tmp$sigma
      # Probability of precipitation
      values(res$prob0)[take] <- 1-pnorm(0,tmp$mu,exp(tmp$sigma))
      # Expectation, and quantiles
      values(res$exp)[take]   <- powexp(tmp$mu,exp(tmp$sigma),1.6) 
      q75 <- qnorm(0.75,tmp$mu,exp(tmp$sigma))
      values(res$q75)[take]   <- ifelse(q75<0,0,q75^1.6)
      q90 <- qnorm(0.90,tmp$mu,exp(tmp$sigma))
      values(res$q90)[take]   <- ifelse(q90<0,0,q90^1.6)

      # --------------------------------------
      # Plotting the data
      # --------------------------------------
      x11(); par(mfrow=c(2,3))

      # Location
      plot(res$mu,    col=diverge_hcl(51,h=c(260,305),power=1),
           main=sprintf("Latent location  %s",strftime(date,"%b %d")))
      # Scale
      plot(res$logsd, col=diverge_hcl(51,h=c(260,120),power=1),
           main=sprintf("Latent log-scale %s",strftime(date,"%b %d")))
      # Probability of precipitation
      plot(res$prob0, col=diverge_hcl(51,h=c(260,0),power=.7), zlim=c(0,1),
           main=sprintf("Probability of precipitation %s",strftime(date,"%b %d")))
      # Expectation
      plot(res$exp, col=colors.rain(51),zlim=range(0,cellStats(res$exp,range)),
         main=sprintf("Climatological expectation %s",strftime(date,"%b %d")))
      # Quantiles
      plot(res$q75, col=colors.rain(51),zlim=range(0,cellStats(res$q75,range)),
         main=sprintf("0.75 quantile %s",strftime(date,"%b %d")))
      plot(res$q90, col=colors.rain(51),zlim=range(0,cellStats(res$q90,range)),
         main=sprintf("0.90 quantile %s",strftime(date,"%b %d")))

   }





