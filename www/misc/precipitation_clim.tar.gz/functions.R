# -------------------------------------------------------------------
# - NAME:        functions.R 
# - AUTHOR:      Reto Stauffer
# - DATE:        2016-03-15
# -------------------------------------------------------------------
# - DESCRIPTION: This script contains some helper functions alongside
#                with the "clim.R".
#
#                powexp: computes the expectation of a
#                power-transformed censored normal distribution based
#                on equi-distant quantiles
#
#                nicename: returns a nicer version of the station
#                name as used in the data set.
#
#                getestimates: returns expectation, probability of
#                precipitation, and certain quantiles of the
#                estimated climatologies
#
#                obsquantiles: computes and plots observed quantiles
#
#                colors.rain: specification of the color map for the
#                spatial precipitation plots.
# -------------------------------------------------------------------
# - LICENSE:     Copyright (c) 2016, Reto Stauffer, Department of
#                Statistics, University of Innsbruck, Austria.
#                Contact: reto.stauffer@uibk.ac.at.
#                This script is free software published under the terms
#                of the GPLv3. For details please read the "LICENSE"
#                file which comes alongside this source file.
# -------------------------------------------------------------------
# - EDITORIAL:   2016-03-15, RS: Created file on thinkreto.
# -------------------------------------------------------------------
# - L@ST MODIFIED: 2016-04-03 11:13 on thinkreto
# -------------------------------------------------------------------


# -------------------------------------------------------------------
# Using empirical solution to compute the expectation of the
# left-censored power-transformed normal distribution. 
# -------------------------------------------------------------------
powexp <- function(mean, sd, power = 1, left = 0, n = 5000, FUN = "mean") { 
    if (!is.logical(left) & !missing(power)) {
        if (left < 0) 
            stop(sprintf("Cannot easily apply power parameter %f if left is lower than 0!", 
                power))
    }
    applyfun <- function(x, resfun, p, left) {
        power <-  x[3L]
        x <- qnorm(p, x[1L], x[2L])
        i <- which(x > 0)
        x[i] <- x[i]^power
        if (!is.logical(left)) 
            x[which(x < left)] <- left
        if (is.character(resfun)) {
            if (resfun == "x") return(x)
        }
        do.call(resfun, list(x = x))
    }
    res <- data.frame("mean" = mean,"sd" = sd,"power" = power,"exp" =  rep(NA, length(mean)))
    p   <- seq(0, 1, length.out = (n + 2))[2:(n + 1)]
    return(apply(res, 1, applyfun, resfun = FUN, p = p, left = left))
}


# -------------------------------------------------------------------
# Stations are named like "Obernberg am Brenner (EHYD)". To store
# the estimates with proper file names, the "nicename" function
# converts these into "ObernbergamBrenner". Only used to store and
# load bamlss models.
# -------------------------------------------------------------------
nicename <- function(x) {
   x <- gsub("\ \\(EHYD\\)", "", x)
   x <- gsub("\\.|\ |-|_|\\(|\\)", "", x)
   x
}


# -------------------------------------------------------------------
# Extracting the estimates from the different models which are
# used for plotting.
# -------------------------------------------------------------------
getestimates <- function(file, coord=NULL) {
   # Predict estimates on "newdata". Note that a non-leapyear
   # as this would lead to problems for the GAMLSS models if
   # they are not trained on a leapyear (day 365 not included)
   newdata      <- data.frame("date" = as.Date("2015-01-01") + 0:354)
   newdata$yday <- as.POSIXlt(newdata$date)$yday
   newdata$mon  <- as.POSIXlt(newdata$date)$mon + 1
   # Loading estimates/model
   x <- load(file); x <- eval(parse(text = x))
   # If returned object is a data.frame, this is the "monmod"
   if (is.data.frame(x)) {
      power <- NULL
      match <- match(newdata$mon,monmod$mon)
      newdata$exp    <- x$mean[match]
      newdata$median <- x$median[match]
      newdata$q75    <- x$q75[match]
      newdata$q90    <- x$q90[match]
      newdata$prob0  <- x$prob0[match]
   # Else it is a bamlss model: if the model frame only consists
   # of two columns, this is a single-station model.
   } else if (dim(model.frame(x))[2] == 2) {
      tmp <- predict(x,newdata=newdata)
      # Power parameter
      power <- ifelse(length(tmp)==2,1.6,exp(tmp$lambda[1]))
      newdata$mu     <- tmp$mu; newdata$sd <- exp(tmp$sigma)
      newdata$exp    <- powexp(tmp$mu, exp(tmp$sigma), power = power)
      newdata$median <- ifelse(tmp$mu<0,0,tmp$mu^power)
      newdata$q75    <- qnorm(0.75, tmp$mu, exp(tmp$sigma))^power
      newdata$q90    <- qnorm(0.90, tmp$mu, exp(tmp$sigma))^power
      newdata$prob0  <- 1 - pnorm(0, tmp$mu, exp(tmp$sigma))
   # Else we got the full spatial model
   } else {
      if (!all(c("lon", "lat", "alt") %in% names(coord)))
         stop("Stop in getestimates: coordinates and altitude required for spatial model")
      power <- 1.6
      newdata$lon <- coord$lon; newdata$lat <- coord$lat; newdata$alt <- coord$alt
      tmp <- predict(x, newdata = newdata)
      newdata$mu     <- tmp$mu; newdata$sd <- exp(tmp$sigma)
      newdata$exp    <- powexp(tmp$mu, exp(tmp$sigma), power = power)
      newdata$median <- ifelse(tmp$mu < 0, 0,tmp$mu^power)
      newdata$q75    <- qnorm(0.75, tmp$mu, exp(tmp$sigma))^power
      newdata$q90    <- qnorm(0.90, tmp$mu, exp(tmp$sigma))^power
      newdata$prob0  <- 1 - pnorm(0, tmp$mu, exp(tmp$sigma))
   }
   # Create zoo objects (for plotting later on)
   require("zoo")
   cols <- which(names(newdata) %in% c("mu", "sd", "median", "q75", "q90", "exp", "prob0"))
   res <- as.zoo(newdata[, cols], newdata$yday)
   attr(res, "power") <- power
   res
}


# -------------------------------------------------------------------
# Compute the quantiles (.10,.25,.50,.75,.90) of x and appends them
# to the current plot.
# -------------------------------------------------------------------
obsquantiles <- function(x) {
   if (!all(c("yday", "obs") %in% names(x))) stop("Wrong input to obsquantiles.")
   # Compute the quantiles
   x <- aggregate(x$obs, by = list(x$yday), function(x) quantile(x, c(.1, .25, .5, .75, .9)))
   x <- as.matrix(x)
   # Polygon: x=yday, y=quantiles
   poly_y  <- c(x[, 1], rev(x[, 1]))
   poly_x1 <- c(x[, 2], rev(x[, 6]))
   poly_x2 <- c(x[, 3], rev(x[, 5]))
   # Plotting quantiles
   polygon(poly_y, poly_x1, border = NA, col = rgb(0, 0, 0, 0.2))
   polygon(poly_y, poly_x2, border = NA, col = rgb(0, 0, 0, 0.2))
   # Plotting median
   lines(x[,1], x[,4], col = "gray40")
}


# -------------------------------------------------------------------
# color map for the precipitation plots. Requires colorspace.
# -------------------------------------------------------------------
colors.rain <- function(n, h = c(-160, -38), c. = c(10, 80), l = c(86, 39), 
    power = c(2.75806451612903, 1), fixup = FALSE, gamma = NULL, 
    alpha = 1, ...) 
{
   require("colorspace")
   if (!is.null(gamma)) 
      warning("'gamma' is deprecated and has no effect")
   if (n < 1L) 
      return(character(0L))
   h <- rep(h, length.out = 2L)
   c <- rep(c., length.out = 2L)
   l <- rep(l, length.out = 2L)
   power <- rep(power, length.out = 2L)
   rval <- seq(1, 0, length = n)
   rval <- hex(polarLUV(L = l[2L] - diff(l) * rval^power[2L], 
      C = c[2L] - diff(c) * rval^power[1L], H = h[2L] - diff(h) * 
          rval), fixup = fixup, ...)
   if (!missing(alpha)) {
      alpha <- pmax(pmin(alpha, 1), 0)
      alpha <- format(as.hexmode(round(alpha * 255 + 1e-04)), 
                      width = 2L, upper.case = TRUE)
      rval <- paste(rval, alpha, sep = "")
   }
   return(rval)
}

























